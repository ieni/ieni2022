from turtle import *

t=Turtle()
##t.hidegrid()
t.hideturtle()
t.pencolor("blue")
t.dot(1000)
t.pencolor("black")
t.pensize(6)
t.speed(10)

kleuren = ["red","yellow","green","white","magenta"]

def vijfhoek(a):
  for i in range(5):
    t.forward(a)
    t.right(72)

for i in range(10):
  t.fillcolor(kleuren[i%5])
  t.begin_fill()
  vijfhoek(180)
  t.end_fill()
  t.right(36)

t.pencolor("black")
for i in range(10):
  vijfhoek(180)
  t.right(36)
