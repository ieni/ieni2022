from turtle import *
t=Turtle()
#t.setgrid(10)
t.speed(10)
t.pensize(2)

stappen=[1,2,3,4,5,6,7,8,9]

for i in range(4):
  for s in stappen:
    t.forward(s*20)
    t.left(90)
