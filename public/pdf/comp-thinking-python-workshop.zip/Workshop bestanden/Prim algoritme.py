M = [[0, 7, 0, 5, 0, 0, 0],
    [7, 0, 8, 9, 7, 0, 0],
    [0, 8, 0, 0, 5, 0, 0],
    [5, 9, 0, 0, 15, 6, 0],
    [0, 7, 5, 15, 0, 8, 9],
    [0, 0, 0, 6, 8, 0, 11],
    [0, 0, 0, 0, 9, 11, 0]]

knopen = ["A","B","C","D","E","F","G"]

wel = ["D"]
niet = ["A","B","C","E","F","G"]

while niet != [ ]:
  min=100000
  for P in wel:
    for Q in niet:
      i=knopen.index(P)
      j=knopen.index(Q)
      a=M[i][j]
      if a>0 and a<min :
        min=a
        P1=P
        Q1=Q
  wel.append(Q1)
  niet.remove(Q1)
  print(P1,Q1)
