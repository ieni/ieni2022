from turtle import *
t=Turtle()
t.hideturtle()
#t.hidegrid()
t.speed(10)

def veelhoek(n,a):
  for i in range(n):
    t.forward(a)
    t.left(360/n)

for i in range(8):
  veelhoek(8,100)
  t.left(45)
