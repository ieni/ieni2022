from turtle import *
t=Turtle()
t.hideturtle()
##t.hidegrid()
t.speed(10)

for i in range(45):
  t.forward(4*i)
  t.left(90)
