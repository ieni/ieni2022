def hanoi (n, van, via, naar):
  if n > 0:
    hanoi(n-1, van, naar, via)
    naar.append(van.pop())
    print("t1 =",t1,"  t2 =",t2,"  t3 =",t3)
    hanoi(n-1, via, van, naar)
 
n = 4


t1 = [n-i for i in range(n)]
t2 = []
t3 = []

print()
print("t1 =",t1,"  t2 =",t2,"  t3 =",t3)

hanoi(n, t1, t2, t3)
